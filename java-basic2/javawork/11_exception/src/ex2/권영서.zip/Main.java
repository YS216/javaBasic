package ex2;

public class Main {
    public static void main(String[] args) {
        NumberMenu menu = new NumberMenu();
        menu.menu();
    }
}

